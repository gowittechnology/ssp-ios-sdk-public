//
//  sspadkit.h
//  sspadkit
//
//  Created by Dogus Yigit Ozcelik on 26.03.2021.
//

#import <Foundation/Foundation.h>

//! Project version number for sspadkit.
FOUNDATION_EXPORT double sspadkitVersionNumber;

//! Project version string for sspadkit.
FOUNDATION_EXPORT const unsigned char sspadkitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <sspadkit/PublicHeader.h>


